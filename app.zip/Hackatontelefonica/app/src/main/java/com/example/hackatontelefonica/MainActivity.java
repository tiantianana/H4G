package com.example.hackatontelefonica;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.BatteryManager;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import org.json.JSONException;
import java.io.IOException;

public class MainActivity extends AppCompatActivity {

    private TextView battery_icon;
    private TextView battery_text;
    private Context contexto;

    private BroadcastReceiver mBroadcastReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            int level = intent.getIntExtra(BatteryManager.EXTRA_LEVEL,-1);
            float percentage = level/ (float) 100;
            ViewGroup.LayoutParams layoutParams = battery_icon.getLayoutParams();
            battery_text.setText(level+"%");
            layoutParams.width = (int) (percentage*248);
            battery_icon.setLayoutParams(layoutParams);
        }

    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        requestWindowFeature(Window.FEATURE_ACTION_BAR);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        contexto = getApplicationContext();
        IntentFilter iFilter = new IntentFilter(Intent.ACTION_BATTERY_CHANGED);
        contexto.registerReceiver(mBroadcastReceiver,iFilter);
        battery_icon = (TextView) findViewById(R.id.battery);
        battery_text = (TextView) findViewById(R.id.battery_text);
    }

    public void whatsapp_callback(View v) {
        Intent intent = getPackageManager().getLaunchIntentForPackage("com.whatsapp");
        startActivity(intent);
    }

    // Futura implementacion
    /*
    public void camara_callback(View v) {
        Intent intent = getPackageManager().getLaunchIntentForPackage("com.anydesk.anydeskandroid");
        startActivity(intent);
    }

    public void correo_callback(View v) {
        Intent intent = getPackageManager().getLaunchIntentForPackage("com.google.android.gm");
        startActivity(intent);
    }

    public void google_callback(View v) {
        Intent intent = getPackageManager().getLaunchIntentForPackage("com.android.chrome");
        startActivity(intent);
    }*/



    public void voice_callback(View v) throws JSONException, IOException {
        Intent intent = getPackageManager().getLaunchIntentForPackage("com.fragileheart.recorder");
        startActivity(intent);

        /*
        File path = new File(v.getContext().getFilesDir().getParentFile().getParentFile().getParentFile().getParentFile().getParentFile(),"sdcard/Music/com.fragileheart.recorder/");
        File audio = new File(path,"to_voice_shift.mp3");
        Log.d("EXISTANT", String.valueOf(audio));
        int i = 1;
        while (true){
            if (audio.exists()){
                audio = new File(path,"to_voice_shift"+ i +".mp3");
                Log.d("EXISTANT", String.valueOf(audio));
            } else {
                audio = new File(path,"to_voice_shift"+ (i - 1) +".mp3");
                Log.d("LASTEST", String.valueOf(audio));
                break;
            }
            i++;

        }
        while (!audio.exists()){}
        try {
            Thread.sleep(5000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        Log.d("TO_SEARCH", String.valueOf(audio));
        Log.d("TO_SEARCH", String.valueOf(audio.exists()));

        //Mandar el audio a la api
        // RequestQueue volleyQueue = Volley.newRequestQueue(MainActivity.this);
        String url = "http://c920-195-55-210-1.eu.ngrok.io";

        // since the response we get from the api is in JSON, we
        // need to use `JsonObjectRequest` for parsing the
        // request response



        //MultipartEntity reqEntity = new MultipartEntity("", ContentType.MULTIPART_FORM_DATA.getMimeType(), );
        //reqEntity.addPart("file", new FileBody(audio));

        HttpClient client = org.apache.http.impl.client.HttpClients.createDefault();
        HttpPost post = new HttpPost(url+ "/upload");
        List<NameValuePair> params = new ArrayList<NameValuePair>(1);
        params.add(new BasicNameValuePair("file","a"));
        post.setEntity(new UrlEncodedFormEntity(params,"UTF-8"));

        HttpResponse response = client.execute(post);
        HttpEntity entity = response.getEntity();
        Log.d("ENTITY", String.valueOf(entity.getContent()));
       // post.setEntity(reqEntity);
        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Request.Method.POST,url+"/upload",reqEntity, (Response.Listener<JSONObject>) response -> {
                    // get the image url from the JSON object
                    String dogImageUrl;
                    try {
                        dogImageUrl = response.getString("message");
                        // load the image into the ImageView using Glide.
                        Log.d("RESPONSE",dogImageUrl);
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                },
                (Response.ErrorListener) error -> {
                    // make a Toast telling the user
                    // that something went wrong
                    // log the error message in the error stream
                    Log.e("ERROR", String.valueOf(error));
                }
        ) {
            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                final Map<String, String> headers = new HashMap<>();
                headers.put("content-type", "application/json");//put your token here
                return headers;
            }
        } ;


        Log.d("REQUEST", jsonObjectRequest.toString());
        volleyQueue.add(jsonObjectRequest);
        Log.d("HERE","");


/*
        while (!audio.exists()){}

        Log.d("TO_SEARCH", String.valueOf(audio));
        Log.d("TO_SEARCH", String.valueOf(audio.exists()));
*/


       /* boolean flag = false;
        File file;
        while (!flag) {
            file = new File("Music/com.fragileheart.recorder/to_voice_shift.mp3");
            if (file.exists()) {
                break;
            } else {

            }
        }
        */

        //intent = getPackageManager().getLaunchIntentForPackage("com.android.chrome");
        //startActivity(intent);

    }


    /*ImageButton whatsapp = (ImageButton) findViewById(R.id.whatsapp);
    whatsapp.setOnClickListener(new View.OnClickListener() {
        public void onClick(View v) {

        }
    });*/

        //    ImageButton boton = (ImageButton) findViewById(R.id.whatsapp);
        // View.OnClickListener(new View.OnClickListener() )


}



